## Problem
This is a two part problem:
1. First, write a series of instructions on how to build out an LRU Cache (pretend 
the person you're writing to has no idea how to build one. Don't forget to address
the reasoning behind using particular data structures).
2. Implement an LRU Cache from scratch with no outside references. **Don't look 
at the code or instructions from your homework!**

## Solution

### Part 1
Write first part here:
1. 
2. 

### Part 2
```ruby
class LRUCache
end
```