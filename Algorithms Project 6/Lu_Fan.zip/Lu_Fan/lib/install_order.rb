# Given an Array of tuples, where tuple[0] represents a package id,
# and tuple[1] represents its dependency, determine the order in which
# the packages should be installed. Only packages that have dependencies
# will be listed, but all packages from 1..max_id exist.

# N.B. this is how `npm` works.

# Import any files you need to
require 'byebug'
require_relative 'graph'
require_relative 'topological_sort'


def install_order(arr)
  max_id = arr.flatten.max
  graph = []
  hash = Hash.new
  (1..max_id).each do |el|
    vertex = Vertex.new(el)
    hash[el] = vertex
    graph.push(vertex)
  end
  arr.each do |tuple|
    Edge.new(hash[tuple[1]], hash[tuple[0]])
  end
  topological_sort(graph).map(&:value)
end
